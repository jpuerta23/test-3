import { defineConfig } from 'vite';

export default defineConfig({
  esbuild: {
    // Desactiva JSX explícitamente para archivos .js
    jsx: false,
  },
  resolve: {
    // Opcional: especifica extensiones si es necesario
    extensions: ['.js', '.json'],
  },
});

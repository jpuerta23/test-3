// ...existing code...

function validateAccount(account, password) {
    const accountsDB = {
        "user1": "password123",
        "user2": "securePass456"
    };

    if (!accountsDB[account]) {
        return { success: false, message: "La cuenta no existe." };
    }

    if (accountsDB[account] !== password) {
        return { success: false, message: "La contraseña es inválida." };
    }

    return { success: true, message: "Inicio de sesión exitoso." };
}

// Ejemplo de uso:
const result = validateAccount("user1", "wrongPassword");
console.log(result.message); // Muestra el mensaje correspondiente

// ...existing code...

const auth = require('./auth');

function login(account, password) {
    const validationResult = auth.validateAccount(account, password);

    if (!validationResult.success) {
        console.error(validationResult.message);
        return false;
    }

    console.log(validationResult.message);
    return true;
}

// Ejemplo de uso:
login("user1", "password123"); // Inicio de sesión exitoso
login("user3", "password123"); // La cuenta no existe
login("user1", "wrongPassword"); // La contraseña es inválida

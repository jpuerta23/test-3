import axios from 'axios';

const API_URL = 'http://localhost:3000/users';

export const login = async (username, password) => {
  const response = await axios.get(API_URL, {
    params: { username, password }
  });
  return response.data.length ? response.data[0] : null;
};

export const register = async (user) => {
  const response = await axios.post(API_URL, user);
  return response.data;
};

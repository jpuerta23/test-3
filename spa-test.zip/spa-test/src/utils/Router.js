import { getUserSession } from '../services/storageService';

export const protectRoute = (role, redirectPath) => {
  const user = getUserSession();
  if (!user || (role && user.role !== role)) {
    window.location.href = redirectPath; // Ensure redirectPath matches the correct file paths
  }
};

export const redirectAuthenticated = (redirectPath) => {
  const user = getUserSession();
  if (user) {
    window.location.href = redirectPath; // Ensure redirectPath matches the correct file paths
  }
};

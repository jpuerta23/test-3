import React, { useState } from 'react';
import Register from './Register.js';


const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('visitor');
  const [success, setSuccess] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    const user = { username, password, role };
    await register(user);
    setSuccess('Registration successful!');
  };

  return (
    <form onSubmit={handleRegister}>
      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <select value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="visitor">Visitor</option>
        <option value="administrator">Administrator</option>
      </select>
      <button type="submit">Register</button>
      {success && <p>{success}</p>}
    </form>
  );
};

export default Register;
